package com.rabbiter.em.mapper;

import com.rabbiter.em.entity.OrderGoods;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface OrderGoodsMapper extends BaseMapper<OrderGoods> {

}
