package com.rabbiter.em.mapper;

import com.rabbiter.em.entity.Address;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface AddressMapper extends BaseMapper<Address> {

}
