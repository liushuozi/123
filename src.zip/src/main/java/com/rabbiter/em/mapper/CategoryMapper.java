package com.rabbiter.em.mapper;

import com.rabbiter.em.entity.Category;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface CategoryMapper extends BaseMapper<Category> {

}
