package com.rabbiter.em.entity;

public enum AuthorityType {
    requireLogin,
    requireAuthority,
    noRequire
}
